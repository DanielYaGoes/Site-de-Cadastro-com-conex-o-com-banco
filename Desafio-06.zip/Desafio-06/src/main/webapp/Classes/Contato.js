class Contato {
    constructor(nome1, email1, telefone1,id,pessoa) {
        this.nome = nome1;
        this.email = email1;
        this.telefone = telefone1;
        this.id =id;
        this.idPessoa = pessoa;
    }

}