angular.module("ListaDePessoas", ["ngRoute"]);

